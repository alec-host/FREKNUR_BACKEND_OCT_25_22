Requirements install

[python-dotenv]: reads key-value from a .env & set them as environment variable
pip install python-dotenv

[python-interface]: library for declaring interfaces & for statically asserting that classes implements those interfaces.
pip install python-interface
