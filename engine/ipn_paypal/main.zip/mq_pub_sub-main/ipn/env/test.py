#!/usr/bin/python

def message():
	print('hello word')
	
	
if __name__== '__main__':
	try:
		message()
	except KeyboardInterrupt:
		exit()
		