#!/usr/bin/python

from interface import Interface

class InterfaceRabbitMqConnection(Interface):

	def create_connection(self,host):
		pass